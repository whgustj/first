from pico2d import *
import random
import platform
import os
if platform.architecture()[0] == '32bit':
       os.environ["PYSDL2_DLL_PATH"] = "./SDL2/x86"
else:
     os.environ["PYSDL2_DLL_PATH"] = "./SDL2/x64"


running = None
flym = None


class Space:
    def __init__(self):
        self.x, self.y = 300, 500
        self.image = load_image('Space.png')


    def update(self):
        self.y = self.y - random.randint(2, 10)
        if self.y <= 100 :
            self.y = 600

    def draw(self):
        self.image.draw(self.x, self.y)

class Fly:
    image = None

    def __init__(self):
        self.x, self.y = 250, 100
        #self.image = load_image('flym.png')
        if Fly.image == None:
            Fly.image = load_image('flym.png')

    def handle_event(self,event):
        if event.type == SDL_KEYDOWN:
           if event.key == SDLK_RIGHT:
               self.x = self.x + 30
           if event.key == SDLK_LEFT:
               self.x = self.x - 30

    def update(self):
        pass

    def draw(self):
        self.image.draw(self.x, self.y)


    def get_bb(self):
        return self.x - 60, self.y - 50, self.x + 60, self.y + 50


    def draw_bb(self):
        draw_rectangle(*self.get_bb())


class Meteo:
    image = None

    def __init__(self):
        self.x,self.y = random.randint(100, 600), 600
        self.fall_speed = random.randint(50, 120)
        if Meteo.image == None:
            Meteo.image = load_image('Meteo.png')

    def draw(self):
        self.image.draw(self.x, self.y)

    def update(self):
        self.y = self.y - 8
        if self.y < 100:
            self.x , self.y = random.randint(100, 600), 700

    def draw(self):
        self.image.draw(self.x, self.y)

    def get_bb(self):
        return self.x - 30, self.y - 30, self.x + 30, self.y + 30

    def draw_bb(self):
        draw_rectangle(*self.get_bb())

class Heart1:

        def __init__(self):
            self.x, self.y = 450, 100
            self.image = load_image('hhh.png')

        def update(self):
            if collide(flym, meteo):
               del (heart1)

        def draw(self):
            self.image.draw(self.x, self.y)




class Heart2:
    def __init__(self):
        self.x, self.y = 500, 100
        self.image = load_image('hhh.png')

    def update(self):
        pass

    def draw(self):
        self.image.draw(self.x, self.y)


class Heart3:
    def __init__(self):
        self.x, self.y = 550, 100
        self.image = load_image('hhh.png')

    def update(self):
        pass

    def draw(self):
        self.image.draw(self.x, self.y)


def handle_events():
    global running
    global flym, meteo, heart1, space

    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            running = False
        elif event.type == SDL_KEYDOWN and event.key == SDLK_ESCAPE:
            running = False


        else:
            flym.handle_event(event)

def collide(a, b):
    left_a, bottom_a, right_a, top_a = a.get_bb()
    left_b, bottom_b, right_b, top_b = b.get_bb()

    if left_a > right_b: return False
    if right_a < left_b: return False
    if top_a < bottom_b: return False
    if bottom_a > top_b: return False

    return True



def main():

    open_canvas(600, 700)

    global flym
    global running
    heart1 = Heart1()
    heart2 = Heart2()
    heart3 = Heart3()
    space = Space()
    flym = Fly()
    meteo = Meteo()
    meteos =[Meteo() for i in range(10)]
    running = True


    while running:
        if collide(flym, meteo):
            del (heart1)

        handle_events()

        flym.update()
        meteo.update()
        space.update()


        clear_canvas()
        space.draw()


        heart1.draw()
        heart2.draw()
        heart3.draw()
        flym.draw()

        flym.draw_bb()
        meteo.draw_bb()
        #if collide(flym, meteo):
        #   del (heart1)

        for meteo in meteos:
            meteo.draw()




        update_canvas()


        delay(0.04)
    close_canvas()


    flym.draw()


if __name__ == '__main__':
    main()